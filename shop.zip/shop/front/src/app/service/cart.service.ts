import { Injectable } from '@angular/core';
import { Product } from '../bean/product';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { environment }  from '../../environments/environment';
import { ProductService } from '../service/product.service';
import { Cart } from '../bean/cart';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private service: Http;
  private productService: ProductService;

  constructor(p_service: Http, p_productService: ProductService) {
    this.service = p_service;
    this.productService = p_productService;
  }

  public getCartProducts( p_carts: Cart[] ): Promise<Array<Product>> {
    // on récupère l'ensemble des produits 
    return this.productService.getProducts().then(

      ( products: Product[] ): Array<Product> => {

        // on crée un tableau de résultats
        let results: Array<Product> = new Array<Product>();

        // on boucle sur tout le panier
        for( let i:number = 0 ; i < p_carts.length; i++ ){

          // et on compare le foreignId de l'élement du panier 
          // en cour à celui de tous les produits du catalogue
          for( let j: number = 0; j < products.length; j++ ){

            // si l'un des produits possède un id correspondant
            // au id_product alors on le pousse dans le tableau de résultat
            if( products[j].id === p_carts[i].id_product ){
              results.push(products[j]);
            }
          }
        }

        return results;
      }
    )
}
// Afficher le Panier
public getCarts(): Promise<Array<Cart>> {
    const promise: Promise<Array<Cart>> = this.service.get(
      environment.getCartURL
    ).toPromise()
      .then(
        (rep: Response): Array<Cart> => {
          return rep.json() as Array<Cart>;
        }
      ).catch(
        (error: any): Promise<any> => {
          return Promise.reject(error);
        }
      );

    return promise;

  }
//Ajouter dans le Panier
  public addToCart( id:number ): Promise<Object>{

    let promise: Promise<Object> = null;
    let body: URLSearchParams = new URLSearchParams();
    let headers: Headers = new Headers(
      { 'Content-Type' : 'application/x-www-form-urlencoded' }
    );
    let options:RequestOptions = new RequestOptions();

    body.set( 'id_product', id.toString());
    options.headers = headers;

    promise = this.service.post(
                              environment.postCartURL, 
                              body,
                              options
                            )
                            .toPromise()
                            .then(
                              ( rep: Response ):Object => {
                                return rep.json();
                              }
                            )
                            .catch(
                              (error: any): Promise<any> => {
                                return Promise.reject(error);
                              }
                            );

    return promise;
  }
//Suprimmer du panier
  public removeCart( p_cart: Cart ): Promise<Object>{    
    let promise: Promise<Object> = null;
    let options: RequestOptions  = new RequestOptions();
    options.params              = new URLSearchParams();
    
    options.params.set("id", p_cart.id.toString());
    options.params.set("api", "azerty123");

    promise = this.service.delete(
                              environment.delCartURL,
                              options
                            )
                            .toPromise()
                            .then(
                              ( rep: Response ):Object => {
                                return rep.json();
                              }
                            )
                            .catch(
                              (error:any): Promise<any> => {
                                return Promise.reject(error);
                              }
                            );

    return promise;
  }

}

