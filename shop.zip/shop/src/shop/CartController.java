package shop;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import shop.model.CartModel;
import shop.model.CartViewModel;

//@WebServlet( name="Cart", urlPatterns = {"/Cart", "/Cart/add", "/Cart/rem"} )

public class CartController extends HttpServlet {
	


	public CartController() {
		super();
	}

	
	public void doGet(
			HttpServletRequest p_request, 
			HttpServletResponse p_response

	) throws ServletException, IOException {

		System.out.println(" Cart Controller doGet ");
		
		p_response.setHeader("Access-Control-Allow-Origin", "*");
		p_response.setCharacterEncoding("utf-8");

		// si la connexion � la bdd a �chou� alors..
		if (CartModel.getInstance().isConnected() == false) 
		{
			// on redirige vers la page FailureSQL
			this.getServletContext().getRequestDispatcher("/FailureSQL.jsp").forward(p_request, p_response);
		} 
		else // sinon ...
		{
			// on r�cup�re le Cartue et on l'affiche
			p_request.setAttribute("cart", CartModel.getInstance().getCart());
			
			// Modified by Jean on Tuesday 12 June
			// Display view of products in cart instead of 2 id's only
			//p_request.setAttribute("CartView", CartViewModel.getInstance().getCart());
			
			
			this.getServletContext().getRequestDispatcher("/Cart.jsp").forward(p_request, p_response);
		}

	}

	public void doPost(

			HttpServletRequest p_request, HttpServletResponse p_response

	) throws ServletException, IOException {
		

		System.out.println(" Cart Controller doPost ");
		
		p_response.setHeader("Access-Control-Allow-Origin", "*");
		p_response.setCharacterEncoding("utf-8");

		int len = CartModel.getInstance().getCart().size();
		boolean success = false;

		
		if (p_request.getParameter("p_Product_id") != null) {

//			Long price = Float.parseFloat(p_request.getParameter("price"));
	//		float tva = Float.parseFloat(p_request.getParameter("tva"));
			
			Long  Product_id =Long.parseLong(p_request.getParameter("p_Product_id"));
			

			CartModel.getInstance().add(Product_id);
            
			success = (CartModel.getInstance().getCart().size() > len);
		}

		if (success == true) {
			this.getServletContext().getRequestDispatcher("/Success.jsp").forward(p_request, p_response);
		} else {
			this.getServletContext().getRequestDispatcher("/Failure.jsp").forward(p_request, p_response);
		}

	}

	public void doOptions(HttpServletRequest p_request, HttpServletResponse p_response)
			throws ServletException, IOException {


		System.out.println(" Cart Controller doOptions ");
		
		p_response.setHeader("Access-Control-Allow-Origin", "*");
		p_response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		p_response.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
		p_response.setCharacterEncoding("utf-8");

		this.getServletContext().getRequestDispatcher("/Success.jsp").forward(p_request, p_response);

	}

	public void doDelete(

			HttpServletRequest p_request, HttpServletResponse p_response

	) throws ServletException, IOException {
		

		System.out.println(" Cart Controller doDelete ");
		
		p_response.setHeader("Access-Control-Allow-Origin", "*");
		p_response.setCharacterEncoding("utf-8");

		boolean success = false;

		if (p_request.getParameter("id") != null && p_request.getParameter("api") != null) {
			int id = Integer.parseInt(p_request.getParameter("id"));
			String apiKey = p_request.getParameter("api");

			if (apiKey.equals("azerty123")) {

				success = CartModel.getInstance().removeProductById(id);

			}
		}

		if (success == true) {
			this.getServletContext().getRequestDispatcher("/Success.jsp").forward(p_request, p_response);
		} else {
			this.getServletContext().getRequestDispatcher("/Failure.jsp").forward(p_request, p_response);
		}

	}

}
