package shop.model.bean;

//import shop.$missing$;

public class Cart {
	
	private Long id; 
	private Long productid;


	public Cart( ){

		System.out.println(" Model Bean Cart Constructor ");
	}

	public Cart( long p_Product_id) 
		{
		
		this.productid=p_Product_id;
		
		System.out.println(" Model Bean Cart Constructor w/ arguments");
	}
	

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getProductid() {
		return productid;
	}

	public void setProductid(Long productid) {
		this.productid = productid;
	}

	public String toString() {		
		System.out.println(" Model Bean to String ");
		String data = "{";
	
		data += " \"id\": \""	+ this.id		+ "\",";
		data += " \"Product_id\": \""+ this.productid	+ "\"";
		data += "}";
		
		return data;
	}
}