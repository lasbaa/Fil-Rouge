package shop.model;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import shop.model.bean.Cart;
import shop.model.bean.Product;

public class CartViewModel {
	

	private static CartViewModel instance = null;
	
	
		public static CartViewModel getInstance() {
			System.out.println(" Cart View Model Get Instance ");
			if( CartViewModel.instance == null ) {
				CartViewModel.instance = new CartViewModel();
			}
			
			return CartViewModel.instance;
		}

		
		/***********************************************/
		/***********************************************/
		/***********************************************/
		private boolean connected;
		private Connection bdd;
		private SessionFactory fact;
		
		private CartViewModel(){
			super();
			
			System.out.println(" Cart View Model Constructor ");
			
			// on n'est pas connect� par d�faut
			this.connected 	= false;
			
			// on va chercher un fabricant de "registre hibernate" ( un objet de config )
			StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
			
			// le fabricant va utilier le fichier hibernate.cfg.xml pour construire
			// un registre.
			StandardServiceRegistry reg = builder.configure().build();
			
			// maintenant on va donner le registre � la SessionFactory
			SessionFactory fact = new MetadataSources(reg)
										.buildMetadata()
										.buildSessionFactory();
			
			this.fact = fact;
			this.connected 	= true;
			
			
		}
		
		public boolean isConnected() {
			System.out.println(" Cart View Model Is Connected ");
			return this.connected;
		}
		/***********************************************/
		/***********************************************/
		/**
		 * @throws SQLException *********************************************/
		
		public ArrayList<Product> getCart(){
			
			System.out.println(" Cart View Model get ");
			//on cr�e un tableau de produits vide
			ArrayList<Product> results = new ArrayList<Product>();
			
			Session bdd = this.fact.openSession();
			bdd.beginTransaction();
			
			//results = (ArrayList<Product>) bdd.createQuery("from Cart").list();
			// Modified by Jean on Tuesday 12 June
			// Display view of products in cart instead of 2 id's only
			results = (ArrayList<Product>) bdd.createQuery("from vue_panier_products").list();
			
			bdd.getTransaction().commit();
			
			bdd.close();
			
			return results;
		}

		
	}
